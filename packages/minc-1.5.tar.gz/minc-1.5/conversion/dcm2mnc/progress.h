extern void progress(long index, int end, const char *message);
