
extern void afEyeNearFar(GLfloat fnear, GLfloat ffar);
extern void afFogStartEnd(GLfloat start, GLfloat end);
extern void afFogMode(GLenum mode);
extern void afFogDensity(GLfloat density);
extern void afFogColor(GLfloat red, GLfloat green, GLfloat blue);
extern void afDoFinalFogPass(GLint x, GLint y, GLsizei width, GLsizei height);

